
const fs = require('fs');
const path = require('path');
const initSqlJs = require('sql.js');

const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
const dbPath = path.join(dataDir, 'pizzaria.sqlite');

let SQL = null;
let db = null;

async function load() {
  if (db) return db;
  if (!SQL) {
    SQL = await initSqlJs({
      locateFile: file => path.join(__dirname, 'node_modules/sql.js/dist', file)
    });
  }
  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
    migrate();
    seed();
    persist();
  }
  return db;
}

function persist() {
  if (!db) return;
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(dbPath, buffer);
}

function run(sql, params = []) {
  const stmt = db.prepare(sql);
  stmt.bind(params);
  stmt.step();
  stmt.free();
  persist();
}

function execMany(sql) {
  db.exec(sql);
  persist();
}

function get(sql, params = []) {
  const stmt = db.prepare(sql);
  stmt.bind(params);
  const row = stmt.step() ? stmt.getAsObject() : null;
  stmt.free();
  return row;
}

function all(sql, params = []) {
  const stmt = db.prepare(sql);
  stmt.bind(params);
  const rows = [];
  while (stmt.step()) rows.push(stmt.getAsObject());
  stmt.free();
  return rows;
}

function migrate() {
  db.exec(`
  PRAGMA foreign_keys = ON;

  CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE
  );

  CREATE TABLE IF NOT EXISTS pizzas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    price REAL NOT NULL DEFAULT 0,
    category_id INTEGER,
    is_active INTEGER NOT NULL DEFAULT 1,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    phone TEXT
  );

  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL,
    created_at TEXT NOT NULL,
    total REAL NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL,
    pizza_id INTEGER NOT NULL,
    qty INTEGER NOT NULL,
    unit_price REAL NOT NULL,
    subtotal REAL NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (pizza_id) REFERENCES pizzas(id) ON DELETE RESTRICT
  );
  `);
}

function seed() {
  const count = get('SELECT COUNT(*) as c FROM categories').c || 0;
  if (count === 0) {
    ['Tradicionais','Especiais','Doces','Vegetarianas'].forEach(n => {
      run('INSERT INTO categories (name) VALUES (?)', [n]);
    });
  }
  const pcount = get('SELECT COUNT(*) as c FROM pizzas').c || 0;
  if (pcount === 0) {
    const cat = get('SELECT id FROM categories WHERE name = ?', ['Tradicionais']);
    run('INSERT INTO pizzas (name, description, price, category_id, is_active) VALUES (?,?,?,?,1)',
      ['Margherita','Molho de tomate, mussarela e manjericão', 39.9, cat?.id || null]);
    run('INSERT INTO pizzas (name, description, price, category_id, is_active) VALUES (?,?,?,?,1)',
      ['Calabresa','Calabresa fatiada e cebola', 42.9, cat?.id || null]);
  }
}

module.exports = {
  load,
  run: (...a) => run(...a),
  execMany: (...a) => execMany(...a),
  get: (...a) => get(...a),
  all: (...a) => all(...a),
  persist
};
