
# Pizzaria Admin — SQL.js (sem compilação)

Projeto painel **admin** de pizzaria com UI aprimorada:
- **Tailwind** + **Chart.js** (via CDN)
- **SQL.js (WASM)** em Node: não precisa Visual Studio nem compilar nada
- Banco persistido em arquivo `data/pizzaria.sqlite`

## Rodar
```bash
npm install
npm start
# abre http://localhost:3000
```

> Se aparecer aviso sobre `sql-wasm.wasm`, não se preocupe: o projeto carrega automaticamente do `node_modules/sql.js/dist/`.
