
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const methodOverride = require('method-override');
const DB = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(methodOverride('_method'));

// middleware para garantir DB carregado
app.use(async (req, res, next) => {
  try {
    await DB.load();
    res.locals.currentPath = req.path;
    next();
  } catch (e) {
    next(e);
  }
});

// Home / Dashboard
app.get('/', (req, res) => {
  const totalPizzas = DB.get('SELECT COUNT(*) as c FROM pizzas').c;
  const totalCategorias = DB.get('SELECT COUNT(*) as c FROM categories').c;
  const totalClientes = DB.get('SELECT COUNT(*) as c FROM customers').c;
  const totalPedidos = DB.get('SELECT COUNT(*) as c FROM orders').c;
  const ultimosPedidos = DB.all(`
    SELECT o.id, c.name as cliente, o.total, o.created_at
    FROM orders o
    LEFT JOIN customers c ON c.id = o.customer_id
    ORDER BY o.created_at DESC
    LIMIT 5
  `);
  // para gráficos
  const vendasPorDia = DB.all(`
    SELECT substr(created_at,1,10) as dia, SUM(total) as total
    FROM orders
    GROUP BY dia
    ORDER BY dia DESC
    LIMIT 7
  `).reverse();
  const pizzasAtivas = DB.all(`
    SELECT c.name as categoria, COUNT(*) as qnt
    FROM pizzas p LEFT JOIN categories c ON c.id = p.category_id
    WHERE p.is_active = 1
    GROUP BY c.name
  `);
  res.render('pages/dashboard', { totalPizzas, totalCategorias, totalClientes, totalPedidos, ultimosPedidos, vendasPorDia, pizzasAtivas });
});

// ===== Categorias =====
app.get('/categories', (req, res) => {
  const q = req.query.q || '';
  const rows = q
    ? DB.all('SELECT * FROM categories WHERE name LIKE ? ORDER BY name', [`%${q}%`])
    : DB.all('SELECT * FROM categories ORDER BY name');
  res.render('pages/categories/index', { rows, q });
});

app.get('/categories/new', (req, res) => {
  res.render('pages/categories/form', { item: null });
});

app.post('/categories', (req, res) => {
  const { name } = req.body;
  if (!name || name.trim().length < 2) {
    return res.render('pages/categories/form', { item: null, error: 'Nome inválido' });
  }
  DB.run('INSERT INTO categories (name) VALUES (?)', [name.trim()]);
  res.redirect('/categories');
});

app.get('/categories/:id/edit', (req, res) => {
  const item = DB.get('SELECT * FROM categories WHERE id = ?', [req.params.id]);
  if (!item) return res.redirect('/categories');
  res.render('pages/categories/form', { item });
});

app.post('/categories/:id', (req, res) => {
  const { name } = req.body;
  DB.run('UPDATE categories SET name = ? WHERE id = ?', [name.trim(), req.params.id]);
  res.redirect('/categories');
});

app.post('/categories/:id/delete', (req, res) => {
  DB.run('DELETE FROM categories WHERE id = ?', [req.params.id]);
  res.redirect('/categories');
});

// ===== Pizzas =====
app.get('/pizzas', (req, res) => {
  const q = req.query.q || '';
  const pizzas = q
    ? DB.all(`
      SELECT p.*, c.name as category_name
      FROM pizzas p
      LEFT JOIN categories c ON c.id = p.category_id
      WHERE p.name LIKE ? OR p.description LIKE ?
      ORDER BY p.name
    `, [`%${q}%`, `%${q}%`])
    : DB.all(`
      SELECT p.*, c.name as category_name
      FROM pizzas p
      LEFT JOIN categories c ON c.id = p.category_id
      ORDER BY p.name
    `);
  res.render('pages/pizzas/index', { pizzas, q });
});

app.get('/pizzas/new', (req, res) => {
  const categories = DB.all('SELECT * FROM categories ORDER BY name');
  res.render('pages/pizzas/form', { item: null, categories });
});

app.post('/pizzas', (req, res) => {
  const { name, description, price, category_id, is_active } = req.body;
  if (!name || name.trim().length < 2) {
    const categories = DB.all('SELECT * FROM categories ORDER BY name');
    return res.render('pages/pizzas/form', { item: null, categories, error: 'Nome inválido' });
  }
  const priceNum = Number(price || 0);
  DB.run(`
    INSERT INTO pizzas (name, description, price, category_id, is_active)
    VALUES (?,?,?,?,?)
  `, [name.trim(), (description||'').trim(), priceNum, category_id || null, is_active ? 1 : 0]);
  res.redirect('/pizzas');
});

app.get('/pizzas/:id/edit', (req, res) => {
  const item = DB.get('SELECT * FROM pizzas WHERE id = ?', [req.params.id]);
  const categories = DB.all('SELECT * FROM categories ORDER BY name');
  if (!item) return res.redirect('/pizzas');
  res.render('pages/pizzas/form', { item, categories });
});

app.post('/pizzas/:id', (req, res) => {
  const { name, description, price, category_id, is_active } = req.body;
  DB.run(`
    UPDATE pizzas SET name=?, description=?, price=?, category_id=?, is_active=?
    WHERE id = ?
  `, [name.trim(), (description||'').trim(), Number(price||0), category_id || null, is_active ? 1 : 0, req.params.id]);
  res.redirect('/pizzas');
});

app.post('/pizzas/:id/delete', (req, res) => {
  DB.run('DELETE FROM pizzas WHERE id = ?', [req.params.id]);
  res.redirect('/pizzas');
});

// ===== Clientes =====
app.get('/customers', (req, res) => {
  const q = req.query.q || '';
  const rows = q
    ? DB.all(`SELECT * FROM customers WHERE name LIKE ? OR phone LIKE ? ORDER BY name`, [`%${q}%`, `%${q}%`])
    : DB.all(`SELECT * FROM customers ORDER BY name`);
  res.render('pages/customers/index', { rows, q });
});

app.get('/customers/new', (req, res) => {
  res.render('pages/customers/form', { item: null });
});

app.post('/customers', (req, res) => {
  const { name, phone } = req.body;
  if (!name || name.trim().length < 2) {
    return res.render('pages/customers/form', { item: null, error: 'Nome inválido' });
  }
  DB.run('INSERT INTO customers (name, phone) VALUES (?, ?)', [name.trim(), (phone||'').trim()]);
  res.redirect('/customers');
});

app.get('/customers/:id/edit', (req, res) => {
  const item = DB.get('SELECT * FROM customers WHERE id = ?', [req.params.id]);
  if (!item) return res.redirect('/customers');
  res.render('pages/customers/form', { item });
});

app.post('/customers/:id', (req, res) => {
  const { name, phone } = req.body;
  DB.run('UPDATE customers SET name=?, phone=? WHERE id = ?', [name.trim(), (phone||'').trim(), req.params.id]);
  res.redirect('/customers');
});

app.post('/customers/:id/delete', (req, res) => {
  DB.run('DELETE FROM customers WHERE id = ?', [req.params.id]);
  res.redirect('/customers');
});

// ===== Pedidos =====
app.get('/orders', (req, res) => {
  const orders = DB.all(`
    SELECT o.*, c.name as customer_name
    FROM orders o
    LEFT JOIN customers c ON c.id = o.customer_id
    ORDER BY o.created_at DESC
  `);
  res.render('pages/orders/index', { orders });
});

app.get('/orders/new', (req, res) => {
  const customers = DB.all('SELECT * FROM customers ORDER BY name');
  const pizzas = DB.all('SELECT id, name, price FROM pizzas WHERE is_active = 1 ORDER BY name');
  res.render('pages/orders/form', { customers, pizzas, pizzasJSON: JSON.stringify(pizzas) });
});

app.post('/orders', (req, res) => {
  const { customer_id } = req.body;
  let items = [];
  try { items = JSON.parse(req.body.items_json || '[]'); } catch {}
  if (!customer_id || items.length === 0) {
    const customers = DB.all('SELECT * FROM customers ORDER BY name');
    const pizzas = DB.all('SELECT id, name, price FROM pizzas WHERE is_active = 1 ORDER BY name');
    return res.render('pages/orders/form', { customers, pizzas, pizzasJSON: JSON.stringify(pizzas), error: 'Informe cliente e ao menos 1 item' });
  }

  let total = 0;
  const enriched = items.map(it => {
    const pizza = DB.get('SELECT id, price FROM pizzas WHERE id = ?', [it.pizza_id]);
    const qty = Math.max(1, Number(it.qty || 1));
    const unit = pizza ? Number(pizza.price) : 0;
    const subtotal = unit * qty;
    total += subtotal;
    return { pizza_id: it.pizza_id, qty, unit_price: unit, subtotal };
  });

  const now = new Date().toISOString();
  DB.run('INSERT INTO orders (customer_id, created_at, total) VALUES (?,?,?)', [customer_id, now, total]);
  const orderId = DB.get('SELECT last_insert_rowid() as id').id;

  enriched.forEach(it => {
    DB.run('INSERT INTO order_items (order_id, pizza_id, qty, unit_price, subtotal) VALUES (?,?,?,?,?)',
      [orderId, it.pizza_id, it.qty, it.unit_price, it.subtotal]);
  });

  res.redirect('/orders');
});

app.get('/orders/:id', (req, res) => {
  const order = DB.get(`
    SELECT o.*, c.name as customer_name, c.phone as customer_phone
    FROM orders o
    LEFT JOIN customers c ON c.id = o.customer_id
    WHERE o.id = ?
  `, [req.params.id]);
  if (!order) return res.redirect('/orders');
  const items = DB.all(`
    SELECT oi.*, p.name as pizza_name
    FROM order_items oi
    LEFT JOIN pizzas p ON p.id = oi.pizza_id
    WHERE oi.order_id = ?
  `, [order.id]);
  res.render('pages/orders/show', { order, items });
});

// 404 minimal
app.use((req, res) => res.status(404).render('partials/404'));

app.listen(PORT, () => console.log(`Pizzaria Admin rodando em http://localhost:${PORT}`));
